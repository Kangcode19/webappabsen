<?php

/*
|--------------------------------------------------------------------------
| Load The Cached Routes
|--------------------------------------------------------------------------
|
| Here we will decode and unserialize the RouteCollection instance that
| holds all of the route information for an application. This allows
| us to instantaneously load the entire route map into the router.
|
*/

app('router')->setCompiledRoutes(
    array (
  'compiled' => 
  array (
    0 => false,
    1 => 
    array (
      '/sanctum/csrf-cookie' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'sanctum.csrf-cookie',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/_ignition/health-check' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'ignition.healthCheck',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/_ignition/execute-solution' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'ignition.executeSolution',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/_ignition/update-config' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'ignition.updateConfig',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/user' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::7LOzY43ntIMNg9eN',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'login',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/proseslogin' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::jTfmfkFEyW2QuJmD',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/panel' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'loginadmin',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/prosesloginadmin' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::Xyj9pDHYiGiVNpFs',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/dashboard' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::G5rwAG9K52QT9dv3',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/proseslogout' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::6CKbQmH0a2hykIPG',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/presensi/pilihjamkerja' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::lnmGhRyd1BB22MTm',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/presensi/store' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::uegWhEGngSFXpLax',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/presensi/scanqr' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::dzPmvOrfChFMEXiT',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/presensi/storeqr' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::hsLPdZOUgnZ9xNjT',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/editprofile' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::xsGWp862pdRWfoUD',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/presensi/histori' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::5IvaU5luttdoXpkk',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/gethistori' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::2j03QOQW2vbTF2Jf',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/presensi/izin' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::GiIfQVHe9k6sDmpA',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/presensi/buatizin' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::pGNrvKpHyMTpRCvR',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/presensi/storeizin' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::NnT2PkLL9q84Tsn0',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/presensi/cekpengajuanizin' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::CPIKO4ROXxPZgfth',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/izinabsen' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::JaJLdXdClNmnJ2zO',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/izinabsen/store' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::cMJdwirxk4QWQmQa',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/izinsakit' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::7hVIIO2rAzjZhWE3',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/izinsakit/store' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::TPeIqbjwqDJLQe3e',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/izincuti' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::s4EtsAgeSqc5iTCY',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/izincuti/store' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::08fZp9ulttn6tHJr',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/izincuti/getmaxcuti' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::8ra7wLDqkCkgWOAX',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/proseslogoutadmin' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::gWsKMplX4vGFigr9',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/panel/dashboardadmin' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::jgQIdM4ByQ8zaPZe',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/karyawan' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::fRMiIBJKI1f2Ngt1',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/konfigurasi/storesetjamkerja' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::5stdsHau829Tmn4v',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/konfigurasi/updatesetjamkerja' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::wKTXmuuJ1LEQSiUI',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/konfigurasi/storesetjamkerjabydate' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::7MJ4Um2WnTsOMJ2V',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/konfigurasi/deletejamkerjabydate' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::ZEY6JZhxIaF6QmH9',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/presensi/monitoring' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::EeJawmh9xo5GtZ8c',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/getpresensi' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::H7462FiEzoAtKru7',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/tampilkanpeta' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::tIMhd6ToijEDtt2a',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/presensi/laporan' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::WRDhdDFYnw6aWEwV',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/presensi/cetaklaporan' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::iAV7uCC8P8fjAWay',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/presensi/rekap' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::62G3pLhQ1ImdD9ox',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/presensi/cetakrekap' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::leBMAdKJUr93wOb5',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/presensi/izinsakit' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::SdIheVFIN8X5hd5v',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/koreksipresensi' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::DsD0rgplciVkXzxj',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/storekoreksipresensi' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::mlFId0lBOc1YUyXz',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/karyawan/store' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::vdqeblIvuDak16gh',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/karyawan/edit' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::1nwnKQznjqZla2F3',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/departemen' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::rA7t5Kvp6qZoloN0',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/departemen/store' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::kHfdOSSmOO1mazjK',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/departemen/edit' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::8O0ogEFqeXmI78rR',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/presensi/approveizinsakit' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::hhvJm45vvRGyTbfY',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/cabang' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::6cdFX3UUm8t7GzGi',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/cabang/store' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::4dJK4M1KRBExySsh',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/cabang/edit' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::mQr5dG0BuLvamjzx',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/cabang/update' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::r7aDo0n6cAPEK0Fh',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/konfigurasi/lokasikantor' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::MIdmE3gC22L7r96H',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/konfigurasi/updatelokasikantor' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::QiIzznSSNJdnLeCZ',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/konfigurasi/jamkerja' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::64zuMEsDeemXqdkF',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/konfigurasi/storejamkerja' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::wqzRO0ovzfSNkjET',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/konfigurasi/editjamkerja' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::hkif85V0ZwMFKid8',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/konfigurasi/updatejamkerja' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::0rDSEl3O8HylSAxb',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/konfigurasi/jamkerjadept' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::ap6iWXPo1Nn9yMJs',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/konfigurasi/jamkerjadept/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::FTcWSx0iCeo0KYeo',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/konfigurasi/jamkerjadept/store' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::iYc0k365PsQGmgw4',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/konfigurasi/users' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::kyYmImPJpRHw1aZq',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/konfigurasi/users/store' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::sZ3Pg3rghEGZiStP',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/konfigurasi/users/edit' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::09aCZkNPEeETKcpY',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/konfigurasi/harilibur' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::N4whORY7KMtnTKyH',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/konfigurasi/harilibur/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::zwceZylmR0Pi0AAI',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/konfigurasi/harilibur/store' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::D5vmnvUB7efGHXs4',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/konfigurasi/harilibur/edit' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::ifb96GPIQ5ZAlRsw',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/konfigurasi/harilibur/storekaryawanlibur' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::UEBuhtXfTd3PyPmM',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/konfigurasi/harilibur/removekaryawanlibur' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::O6hvMPDFJN4AS8HP',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/cuti' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::RyXfgAOZYp1MBAEo',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/cuti/store' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::wQzOh0ZtkDizVU4c',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/cuti/edit' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::oD7KQPWrbkgWzic3',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/createrolepermission' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::QDOXniNkfYjaiUrG',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/give-user-role' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::lIKsW6TkdEMS9dmT',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/give-role-permission' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::QRB3gD97tyXyEJLU',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
    ),
    2 => 
    array (
      0 => '{^(?|/presensi/([^/]++)/(?|create(*:35)|updateprofile(*:55)|batalkanizinsakit(*:79))|/izin(?|absen/([^/]++)/(?|edit(*:117)|update(*:131))|sakit/([^/]++)/(?|edit(*:162)|update(*:176))|cuti/([^/]++)/(?|edit(*:206)|update(*:220))|/([^/]++)/(?|showact(*:249)|delete(*:263)))|/k(?|aryawan/([^/]++)/(?|resetpassword(*:311)|update(*:325)|delete(*:339)|lockandunlock(?|location(*:371)|jamkerja(*:387)))|onfigurasi/(?|([^/]++)/(?|setjamkerja(*:434)|([^/]++)/([^/]++)/getjamkerjabydate(*:477))|jamkerja(?|/([^/]++)/delete(*:513)|dept/([^/]++)/(?|edit(*:542)|update(*:556)|show(*:568)|delete(*:582)))|users/([^/]++)/(?|update(*:616)|delete(*:630))|harilibur/([^/]++)/(?|update(*:667)|delete(*:681)|set(?|karyawanlibur(*:708)|listkaryawanlibur(*:733))|get(?|setlistkaryawanlibur(*:768)|karyawanlibur(*:789)))))|/departemen/([^/]++)/(?|update(*:831)|delete(*:845))|/c(?|abang/([^/]++)/delete(*:880)|uti/([^/]++)/(?|update(*:910)|delete(*:924))))/?$}sDu',
    ),
    3 => 
    array (
      35 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::qoVFmRxCXJoYyQU3',
          ),
          1 => 
          array (
            0 => 'kode_jam_kerja',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      55 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::P6lSOQqCX5aGwRI8',
          ),
          1 => 
          array (
            0 => 'nik',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      79 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::DNuajL4LWrCjG8C5',
          ),
          1 => 
          array (
            0 => 'kode_izin',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      117 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::lMDfdZYZQRxA6eyQ',
          ),
          1 => 
          array (
            0 => 'kode_izin',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      131 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::YBdkU3O8QSXkBGNW',
          ),
          1 => 
          array (
            0 => 'kode_izin',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      162 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::Cosg3hcbUxeH1n6d',
          ),
          1 => 
          array (
            0 => 'kode_izin',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      176 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::oq6hLdj9Y1wl2RSO',
          ),
          1 => 
          array (
            0 => 'kode_izin',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      206 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::CXPaZ5lWYsTjR0Sq',
          ),
          1 => 
          array (
            0 => 'kode_izin',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      220 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::eHqPzePBdYnBEKPS',
          ),
          1 => 
          array (
            0 => 'kode_izin',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      249 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::HnK0RQow18rYyuLI',
          ),
          1 => 
          array (
            0 => 'kode_izin',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      263 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::rua633diUApwAZB5',
          ),
          1 => 
          array (
            0 => 'kode_izin',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      311 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::FLLOhQsjRFgzyxZe',
          ),
          1 => 
          array (
            0 => 'nik',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      325 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::iGxznVz8KCmX7dgI',
          ),
          1 => 
          array (
            0 => 'nik',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      339 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::S1xUt0JZquJCxLDa',
          ),
          1 => 
          array (
            0 => 'nik',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      371 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::nUrn4XzIk7ZhQTa2',
          ),
          1 => 
          array (
            0 => 'nik',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      387 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::SqSXIVJMaVM25jZY',
          ),
          1 => 
          array (
            0 => 'nik',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      434 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::2jXj4AuUngsizOqD',
          ),
          1 => 
          array (
            0 => 'nik',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      477 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::4PuzTdFet2fGsdtE',
          ),
          1 => 
          array (
            0 => 'nik',
            1 => 'bulan',
            2 => 'tahun',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      513 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::thuLpbcwB2eiprDE',
          ),
          1 => 
          array (
            0 => 'kode_jam_kerja',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      542 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::3C0OkvJ00TbRcAjK',
          ),
          1 => 
          array (
            0 => 'kode_jk_dept',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      556 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::ZjkQ9rkSjyOTvFZr',
          ),
          1 => 
          array (
            0 => 'kode_jk_dept',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      568 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::c23WknyXaK7Tf4CQ',
          ),
          1 => 
          array (
            0 => 'kode_jk_dept',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      582 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::bxtQCYKJJZlyPmGv',
          ),
          1 => 
          array (
            0 => 'kode_jk_dept',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      616 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::eIoLcvO63YgiEic1',
          ),
          1 => 
          array (
            0 => 'id_user',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      630 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::SZK1YUpoNHzUdBDB',
          ),
          1 => 
          array (
            0 => 'id_user',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      667 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::7O7qovS5lfFndind',
          ),
          1 => 
          array (
            0 => 'kode_libur',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      681 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::FyIXb3NX8AsRxJwn',
          ),
          1 => 
          array (
            0 => 'kode_libur',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      708 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::XPMziF7T9fMrH6W6',
          ),
          1 => 
          array (
            0 => 'kode_libur',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      733 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::FLMj9BR42KsmYim0',
          ),
          1 => 
          array (
            0 => 'kode_libur',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      768 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::0DNWj4xOol1YWgJx',
          ),
          1 => 
          array (
            0 => 'kode_libur',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      789 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::8fwNyp7POie0sDH4',
          ),
          1 => 
          array (
            0 => 'kode_libur',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      831 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::7ctOyuCE0XxZaWqU',
          ),
          1 => 
          array (
            0 => 'kode_dept',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      845 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::yxAObh0QXcvCnE5X',
          ),
          1 => 
          array (
            0 => 'kode_dept',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      880 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::6DaAk8tJTsKIRt0d',
          ),
          1 => 
          array (
            0 => 'kode_cabang',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      910 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::ngHEoYRFBlGkeKNV',
          ),
          1 => 
          array (
            0 => 'kode_cuti',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      924 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::clodYZkdAX4aqk29',
          ),
          1 => 
          array (
            0 => 'kode_cuti',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => NULL,
          1 => NULL,
          2 => NULL,
          3 => NULL,
          4 => false,
          5 => false,
          6 => 0,
        ),
      ),
    ),
    4 => NULL,
  ),
  'attributes' => 
  array (
    'sanctum.csrf-cookie' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'sanctum/csrf-cookie',
      'action' => 
      array (
        'uses' => 'Laravel\\Sanctum\\Http\\Controllers\\CsrfCookieController@show',
        'controller' => 'Laravel\\Sanctum\\Http\\Controllers\\CsrfCookieController@show',
        'namespace' => NULL,
        'prefix' => 'sanctum',
        'where' => 
        array (
        ),
        'middleware' => 
        array (
          0 => 'web',
        ),
        'as' => 'sanctum.csrf-cookie',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'ignition.healthCheck' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '_ignition/health-check',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'Spatie\\LaravelIgnition\\Http\\Middleware\\RunnableSolutionsEnabled',
        ),
        'uses' => 'Spatie\\LaravelIgnition\\Http\\Controllers\\HealthCheckController@__invoke',
        'controller' => 'Spatie\\LaravelIgnition\\Http\\Controllers\\HealthCheckController',
        'as' => 'ignition.healthCheck',
        'namespace' => NULL,
        'prefix' => '_ignition',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'ignition.executeSolution' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => '_ignition/execute-solution',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'Spatie\\LaravelIgnition\\Http\\Middleware\\RunnableSolutionsEnabled',
        ),
        'uses' => 'Spatie\\LaravelIgnition\\Http\\Controllers\\ExecuteSolutionController@__invoke',
        'controller' => 'Spatie\\LaravelIgnition\\Http\\Controllers\\ExecuteSolutionController',
        'as' => 'ignition.executeSolution',
        'namespace' => NULL,
        'prefix' => '_ignition',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'ignition.updateConfig' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => '_ignition/update-config',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'Spatie\\LaravelIgnition\\Http\\Middleware\\RunnableSolutionsEnabled',
        ),
        'uses' => 'Spatie\\LaravelIgnition\\Http\\Controllers\\UpdateConfigController@__invoke',
        'controller' => 'Spatie\\LaravelIgnition\\Http\\Controllers\\UpdateConfigController',
        'as' => 'ignition.updateConfig',
        'namespace' => NULL,
        'prefix' => '_ignition',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::7LOzY43ntIMNg9eN' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/user',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
        ),
        'uses' => 'O:47:"Laravel\\SerializableClosure\\SerializableClosure":1:{s:12:"serializable";O:46:"Laravel\\SerializableClosure\\Serializers\\Signed":2:{s:12:"serializable";s:295:"O:46:"Laravel\\SerializableClosure\\Serializers\\Native":5:{s:3:"use";a:0:{}s:8:"function";s:77:"function (\\Illuminate\\Http\\Request $request) {
    return $request->user();
}";s:5:"scope";s:37:"Illuminate\\Routing\\RouteFileRegistrar";s:4:"this";N;s:4:"self";s:32:"0000000032f3cd59000000005af0229f";}";s:4:"hash";s:44:"Tt0YV+ZhxjM2zKi2S96P/Ia5i1ZQ8d4BqEmqyE8JltU=";}}',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::7LOzY43ntIMNg9eN',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'login' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '/',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'guest:karyawan',
        ),
        'uses' => 'O:47:"Laravel\\SerializableClosure\\SerializableClosure":1:{s:12:"serializable";O:46:"Laravel\\SerializableClosure\\Serializers\\Signed":2:{s:12:"serializable";s:273:"O:46:"Laravel\\SerializableClosure\\Serializers\\Native":5:{s:3:"use";a:0:{}s:8:"function";s:55:"function () {
        return \\view(\'auth.login\');
    }";s:5:"scope";s:37:"Illuminate\\Routing\\RouteFileRegistrar";s:4:"this";N;s:4:"self";s:32:"0000000032f3cd55000000005af0229f";}";s:4:"hash";s:44:"BxiIcykrmCZtf+RW9qPmao6bj4DWt0UfTqx0UnahR8o=";}}',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'login',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::jTfmfkFEyW2QuJmD' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'proseslogin',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'guest:karyawan',
        ),
        'uses' => 'App\\Http\\Controllers\\AuthController@proseslogin',
        'controller' => 'App\\Http\\Controllers\\AuthController@proseslogin',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::jTfmfkFEyW2QuJmD',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'loginadmin' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'panel',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'guest:user',
        ),
        'uses' => 'O:47:"Laravel\\SerializableClosure\\SerializableClosure":1:{s:12:"serializable";O:46:"Laravel\\SerializableClosure\\Serializers\\Signed":2:{s:12:"serializable";s:278:"O:46:"Laravel\\SerializableClosure\\Serializers\\Native":5:{s:3:"use";a:0:{}s:8:"function";s:60:"function () {
        return \\view(\'auth.loginadmin\');
    }";s:5:"scope";s:37:"Illuminate\\Routing\\RouteFileRegistrar";s:4:"this";N;s:4:"self";s:32:"0000000032f3cd52000000005af0229f";}";s:4:"hash";s:44:"6I5WkxvwbTWqS9fLc4c+bk0q0PAPToNpoUP2cvsb6KI=";}}',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'loginadmin',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::Xyj9pDHYiGiVNpFs' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'prosesloginadmin',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'guest:user',
        ),
        'uses' => 'App\\Http\\Controllers\\AuthController@prosesloginadmin',
        'controller' => 'App\\Http\\Controllers\\AuthController@prosesloginadmin',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::Xyj9pDHYiGiVNpFs',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::G5rwAG9K52QT9dv3' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'dashboard',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:karyawan',
        ),
        'uses' => 'App\\Http\\Controllers\\DashboardController@index',
        'controller' => 'App\\Http\\Controllers\\DashboardController@index',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::G5rwAG9K52QT9dv3',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::6CKbQmH0a2hykIPG' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'proseslogout',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:karyawan',
        ),
        'uses' => 'App\\Http\\Controllers\\AuthController@proseslogout',
        'controller' => 'App\\Http\\Controllers\\AuthController@proseslogout',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::6CKbQmH0a2hykIPG',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::qoVFmRxCXJoYyQU3' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'presensi/{kode_jam_kerja}/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:karyawan',
        ),
        'uses' => 'App\\Http\\Controllers\\PresensiController@create',
        'controller' => 'App\\Http\\Controllers\\PresensiController@create',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::qoVFmRxCXJoYyQU3',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::lnmGhRyd1BB22MTm' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'presensi/pilihjamkerja',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:karyawan',
        ),
        'uses' => 'App\\Http\\Controllers\\PresensiController@pilihjamkerja',
        'controller' => 'App\\Http\\Controllers\\PresensiController@pilihjamkerja',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::lnmGhRyd1BB22MTm',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::uegWhEGngSFXpLax' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'presensi/store',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:karyawan',
        ),
        'uses' => 'App\\Http\\Controllers\\PresensiController@store',
        'controller' => 'App\\Http\\Controllers\\PresensiController@store',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::uegWhEGngSFXpLax',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::dzPmvOrfChFMEXiT' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'presensi/scanqr',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:karyawan',
        ),
        'uses' => 'App\\Http\\Controllers\\PresensiController@scanqr',
        'controller' => 'App\\Http\\Controllers\\PresensiController@scanqr',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::dzPmvOrfChFMEXiT',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::hsLPdZOUgnZ9xNjT' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'presensi/storeqr',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:karyawan',
        ),
        'uses' => 'App\\Http\\Controllers\\PresensiController@storeqr',
        'controller' => 'App\\Http\\Controllers\\PresensiController@storeqr',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::hsLPdZOUgnZ9xNjT',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::xsGWp862pdRWfoUD' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'editprofile',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:karyawan',
        ),
        'uses' => 'App\\Http\\Controllers\\PresensiController@editprofile',
        'controller' => 'App\\Http\\Controllers\\PresensiController@editprofile',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::xsGWp862pdRWfoUD',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::P6lSOQqCX5aGwRI8' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'presensi/{nik}/updateprofile',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:karyawan',
        ),
        'uses' => 'App\\Http\\Controllers\\PresensiController@updateprofile',
        'controller' => 'App\\Http\\Controllers\\PresensiController@updateprofile',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::P6lSOQqCX5aGwRI8',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::5IvaU5luttdoXpkk' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'presensi/histori',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:karyawan',
        ),
        'uses' => 'App\\Http\\Controllers\\PresensiController@histori',
        'controller' => 'App\\Http\\Controllers\\PresensiController@histori',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::5IvaU5luttdoXpkk',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::2j03QOQW2vbTF2Jf' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'gethistori',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:karyawan',
        ),
        'uses' => 'App\\Http\\Controllers\\PresensiController@gethistori',
        'controller' => 'App\\Http\\Controllers\\PresensiController@gethistori',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::2j03QOQW2vbTF2Jf',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::GiIfQVHe9k6sDmpA' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'presensi/izin',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:karyawan',
        ),
        'uses' => 'App\\Http\\Controllers\\PresensiController@izin',
        'controller' => 'App\\Http\\Controllers\\PresensiController@izin',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::GiIfQVHe9k6sDmpA',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::pGNrvKpHyMTpRCvR' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'presensi/buatizin',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:karyawan',
        ),
        'uses' => 'App\\Http\\Controllers\\PresensiController@buatizin',
        'controller' => 'App\\Http\\Controllers\\PresensiController@buatizin',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::pGNrvKpHyMTpRCvR',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::NnT2PkLL9q84Tsn0' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'presensi/storeizin',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:karyawan',
        ),
        'uses' => 'App\\Http\\Controllers\\PresensiController@storeizin',
        'controller' => 'App\\Http\\Controllers\\PresensiController@storeizin',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::NnT2PkLL9q84Tsn0',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::CPIKO4ROXxPZgfth' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'presensi/cekpengajuanizin',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:karyawan',
        ),
        'uses' => 'App\\Http\\Controllers\\PresensiController@cekpengajuanizin',
        'controller' => 'App\\Http\\Controllers\\PresensiController@cekpengajuanizin',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::CPIKO4ROXxPZgfth',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::JaJLdXdClNmnJ2zO' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'izinabsen',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:karyawan',
        ),
        'uses' => 'App\\Http\\Controllers\\IzinabsenController@create',
        'controller' => 'App\\Http\\Controllers\\IzinabsenController@create',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::JaJLdXdClNmnJ2zO',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::cMJdwirxk4QWQmQa' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'izinabsen/store',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:karyawan',
        ),
        'uses' => 'App\\Http\\Controllers\\IzinabsenController@store',
        'controller' => 'App\\Http\\Controllers\\IzinabsenController@store',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::cMJdwirxk4QWQmQa',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::lMDfdZYZQRxA6eyQ' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'izinabsen/{kode_izin}/edit',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:karyawan',
        ),
        'uses' => 'App\\Http\\Controllers\\IzinabsenController@edit',
        'controller' => 'App\\Http\\Controllers\\IzinabsenController@edit',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::lMDfdZYZQRxA6eyQ',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::YBdkU3O8QSXkBGNW' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'izinabsen/{kode_izin}/update',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:karyawan',
        ),
        'uses' => 'App\\Http\\Controllers\\IzinabsenController@update',
        'controller' => 'App\\Http\\Controllers\\IzinabsenController@update',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::YBdkU3O8QSXkBGNW',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::7hVIIO2rAzjZhWE3' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'izinsakit',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:karyawan',
        ),
        'uses' => 'App\\Http\\Controllers\\IzinsakitController@create',
        'controller' => 'App\\Http\\Controllers\\IzinsakitController@create',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::7hVIIO2rAzjZhWE3',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::TPeIqbjwqDJLQe3e' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'izinsakit/store',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:karyawan',
        ),
        'uses' => 'App\\Http\\Controllers\\IzinsakitController@store',
        'controller' => 'App\\Http\\Controllers\\IzinsakitController@store',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::TPeIqbjwqDJLQe3e',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::Cosg3hcbUxeH1n6d' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'izinsakit/{kode_izin}/edit',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:karyawan',
        ),
        'uses' => 'App\\Http\\Controllers\\IzinsakitController@edit',
        'controller' => 'App\\Http\\Controllers\\IzinsakitController@edit',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::Cosg3hcbUxeH1n6d',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::oq6hLdj9Y1wl2RSO' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'izinsakit/{kode_izin}/update',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:karyawan',
        ),
        'uses' => 'App\\Http\\Controllers\\IzinsakitController@update',
        'controller' => 'App\\Http\\Controllers\\IzinsakitController@update',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::oq6hLdj9Y1wl2RSO',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::s4EtsAgeSqc5iTCY' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'izincuti',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:karyawan',
        ),
        'uses' => 'App\\Http\\Controllers\\IzincutiController@create',
        'controller' => 'App\\Http\\Controllers\\IzincutiController@create',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::s4EtsAgeSqc5iTCY',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::08fZp9ulttn6tHJr' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'izincuti/store',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:karyawan',
        ),
        'uses' => 'App\\Http\\Controllers\\IzincutiController@store',
        'controller' => 'App\\Http\\Controllers\\IzincutiController@store',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::08fZp9ulttn6tHJr',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::CXPaZ5lWYsTjR0Sq' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'izincuti/{kode_izin}/edit',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:karyawan',
        ),
        'uses' => 'App\\Http\\Controllers\\IzincutiController@edit',
        'controller' => 'App\\Http\\Controllers\\IzincutiController@edit',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::CXPaZ5lWYsTjR0Sq',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::eHqPzePBdYnBEKPS' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'izincuti/{kode_izin}/update',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:karyawan',
        ),
        'uses' => 'App\\Http\\Controllers\\IzincutiController@update',
        'controller' => 'App\\Http\\Controllers\\IzincutiController@update',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::eHqPzePBdYnBEKPS',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::8ra7wLDqkCkgWOAX' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'izincuti/getmaxcuti',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:karyawan',
        ),
        'uses' => 'App\\Http\\Controllers\\IzincutiController@getmaxcuti',
        'controller' => 'App\\Http\\Controllers\\IzincutiController@getmaxcuti',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::8ra7wLDqkCkgWOAX',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::HnK0RQow18rYyuLI' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'izin/{kode_izin}/showact',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:karyawan',
        ),
        'uses' => 'App\\Http\\Controllers\\PresensiController@showact',
        'controller' => 'App\\Http\\Controllers\\PresensiController@showact',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::HnK0RQow18rYyuLI',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::rua633diUApwAZB5' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'izin/{kode_izin}/delete',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:karyawan',
        ),
        'uses' => 'App\\Http\\Controllers\\PresensiController@deleteizin',
        'controller' => 'App\\Http\\Controllers\\PresensiController@deleteizin',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::rua633diUApwAZB5',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::gWsKMplX4vGFigr9' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'proseslogoutadmin',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'role:administrator|admin departemen,user',
        ),
        'uses' => 'App\\Http\\Controllers\\AuthController@proseslogoutadmin',
        'controller' => 'App\\Http\\Controllers\\AuthController@proseslogoutadmin',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::gWsKMplX4vGFigr9',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::jgQIdM4ByQ8zaPZe' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'panel/dashboardadmin',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'role:administrator|admin departemen,user',
        ),
        'uses' => 'App\\Http\\Controllers\\DashboardController@dashboardadmin',
        'controller' => 'App\\Http\\Controllers\\DashboardController@dashboardadmin',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::jgQIdM4ByQ8zaPZe',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::fRMiIBJKI1f2Ngt1' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'karyawan',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'role:administrator|admin departemen,user',
        ),
        'uses' => 'App\\Http\\Controllers\\KaryawanController@index',
        'controller' => 'App\\Http\\Controllers\\KaryawanController@index',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::fRMiIBJKI1f2Ngt1',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::FLLOhQsjRFgzyxZe' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'karyawan/{nik}/resetpassword',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'role:administrator|admin departemen,user',
        ),
        'uses' => 'App\\Http\\Controllers\\KaryawanController@resetpassword',
        'controller' => 'App\\Http\\Controllers\\KaryawanController@resetpassword',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::FLLOhQsjRFgzyxZe',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::2jXj4AuUngsizOqD' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'konfigurasi/{nik}/setjamkerja',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'role:administrator|admin departemen,user',
        ),
        'uses' => 'App\\Http\\Controllers\\KonfigurasiController@setjamkerja',
        'controller' => 'App\\Http\\Controllers\\KonfigurasiController@setjamkerja',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::2jXj4AuUngsizOqD',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::5stdsHau829Tmn4v' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'konfigurasi/storesetjamkerja',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'role:administrator|admin departemen,user',
        ),
        'uses' => 'App\\Http\\Controllers\\KonfigurasiController@storesetjamkerja',
        'controller' => 'App\\Http\\Controllers\\KonfigurasiController@storesetjamkerja',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::5stdsHau829Tmn4v',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::wKTXmuuJ1LEQSiUI' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'konfigurasi/updatesetjamkerja',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'role:administrator|admin departemen,user',
        ),
        'uses' => 'App\\Http\\Controllers\\KonfigurasiController@updatesetjamkerja',
        'controller' => 'App\\Http\\Controllers\\KonfigurasiController@updatesetjamkerja',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::wKTXmuuJ1LEQSiUI',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::7MJ4Um2WnTsOMJ2V' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'konfigurasi/storesetjamkerjabydate',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'role:administrator|admin departemen,user',
        ),
        'uses' => 'App\\Http\\Controllers\\KonfigurasiController@storesetjamkerjabydate',
        'controller' => 'App\\Http\\Controllers\\KonfigurasiController@storesetjamkerjabydate',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::7MJ4Um2WnTsOMJ2V',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::4PuzTdFet2fGsdtE' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'konfigurasi/{nik}/{bulan}/{tahun}/getjamkerjabydate',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'role:administrator|admin departemen,user',
        ),
        'uses' => 'App\\Http\\Controllers\\KonfigurasiController@getjamkerjabydate',
        'controller' => 'App\\Http\\Controllers\\KonfigurasiController@getjamkerjabydate',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::4PuzTdFet2fGsdtE',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::ZEY6JZhxIaF6QmH9' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'konfigurasi/deletejamkerjabydate',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'role:administrator|admin departemen,user',
        ),
        'uses' => 'App\\Http\\Controllers\\KonfigurasiController@deletejamkerjabydate',
        'controller' => 'App\\Http\\Controllers\\KonfigurasiController@deletejamkerjabydate',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::ZEY6JZhxIaF6QmH9',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::EeJawmh9xo5GtZ8c' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'presensi/monitoring',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'role:administrator|admin departemen,user',
        ),
        'uses' => 'App\\Http\\Controllers\\PresensiController@monitoring',
        'controller' => 'App\\Http\\Controllers\\PresensiController@monitoring',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::EeJawmh9xo5GtZ8c',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::H7462FiEzoAtKru7' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'getpresensi',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'role:administrator|admin departemen,user',
        ),
        'uses' => 'App\\Http\\Controllers\\PresensiController@getpresensi',
        'controller' => 'App\\Http\\Controllers\\PresensiController@getpresensi',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::H7462FiEzoAtKru7',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::tIMhd6ToijEDtt2a' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'tampilkanpeta',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'role:administrator|admin departemen,user',
        ),
        'uses' => 'App\\Http\\Controllers\\PresensiController@tampilkanpeta',
        'controller' => 'App\\Http\\Controllers\\PresensiController@tampilkanpeta',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::tIMhd6ToijEDtt2a',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::WRDhdDFYnw6aWEwV' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'presensi/laporan',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'role:administrator|admin departemen,user',
        ),
        'uses' => 'App\\Http\\Controllers\\PresensiController@laporan',
        'controller' => 'App\\Http\\Controllers\\PresensiController@laporan',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::WRDhdDFYnw6aWEwV',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::iAV7uCC8P8fjAWay' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'presensi/cetaklaporan',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'role:administrator|admin departemen,user',
        ),
        'uses' => 'App\\Http\\Controllers\\PresensiController@cetaklaporan',
        'controller' => 'App\\Http\\Controllers\\PresensiController@cetaklaporan',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::iAV7uCC8P8fjAWay',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::62G3pLhQ1ImdD9ox' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'presensi/rekap',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'role:administrator|admin departemen,user',
        ),
        'uses' => 'App\\Http\\Controllers\\PresensiController@rekap',
        'controller' => 'App\\Http\\Controllers\\PresensiController@rekap',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::62G3pLhQ1ImdD9ox',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::leBMAdKJUr93wOb5' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'presensi/cetakrekap',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'role:administrator|admin departemen,user',
        ),
        'uses' => 'App\\Http\\Controllers\\PresensiController@cetakrekap',
        'controller' => 'App\\Http\\Controllers\\PresensiController@cetakrekap',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::leBMAdKJUr93wOb5',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::SdIheVFIN8X5hd5v' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'presensi/izinsakit',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'role:administrator|admin departemen,user',
        ),
        'uses' => 'App\\Http\\Controllers\\PresensiController@izinsakit',
        'controller' => 'App\\Http\\Controllers\\PresensiController@izinsakit',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::SdIheVFIN8X5hd5v',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::DsD0rgplciVkXzxj' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'koreksipresensi',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'role:administrator|admin departemen,user',
        ),
        'uses' => 'App\\Http\\Controllers\\PresensiController@koreksipresensi',
        'controller' => 'App\\Http\\Controllers\\PresensiController@koreksipresensi',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::DsD0rgplciVkXzxj',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::mlFId0lBOc1YUyXz' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'storekoreksipresensi',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'role:administrator|admin departemen,user',
        ),
        'uses' => 'App\\Http\\Controllers\\PresensiController@storekoreksipresensi',
        'controller' => 'App\\Http\\Controllers\\PresensiController@storekoreksipresensi',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::mlFId0lBOc1YUyXz',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::vdqeblIvuDak16gh' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'karyawan/store',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'role:administrator,user',
        ),
        'uses' => 'App\\Http\\Controllers\\KaryawanController@store',
        'controller' => 'App\\Http\\Controllers\\KaryawanController@store',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::vdqeblIvuDak16gh',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::1nwnKQznjqZla2F3' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'karyawan/edit',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'role:administrator,user',
        ),
        'uses' => 'App\\Http\\Controllers\\KaryawanController@edit',
        'controller' => 'App\\Http\\Controllers\\KaryawanController@edit',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::1nwnKQznjqZla2F3',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::iGxznVz8KCmX7dgI' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'karyawan/{nik}/update',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'role:administrator,user',
        ),
        'uses' => 'App\\Http\\Controllers\\KaryawanController@update',
        'controller' => 'App\\Http\\Controllers\\KaryawanController@update',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::iGxznVz8KCmX7dgI',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::S1xUt0JZquJCxLDa' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'karyawan/{nik}/delete',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'role:administrator,user',
        ),
        'uses' => 'App\\Http\\Controllers\\KaryawanController@delete',
        'controller' => 'App\\Http\\Controllers\\KaryawanController@delete',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::S1xUt0JZquJCxLDa',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::nUrn4XzIk7ZhQTa2' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'karyawan/{nik}/lockandunlocklocation',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'role:administrator,user',
        ),
        'uses' => 'App\\Http\\Controllers\\KaryawanController@lockandunlocklocation',
        'controller' => 'App\\Http\\Controllers\\KaryawanController@lockandunlocklocation',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::nUrn4XzIk7ZhQTa2',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::SqSXIVJMaVM25jZY' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'karyawan/{nik}/lockandunlockjamkerja',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'role:administrator,user',
        ),
        'uses' => 'App\\Http\\Controllers\\KaryawanController@lockandunlockjamkerja',
        'controller' => 'App\\Http\\Controllers\\KaryawanController@lockandunlockjamkerja',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::SqSXIVJMaVM25jZY',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::rA7t5Kvp6qZoloN0' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'departemen',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'role:administrator,user',
          2 => 'permission:view-departemen,user',
        ),
        'uses' => 'App\\Http\\Controllers\\DepartemenController@index',
        'controller' => 'App\\Http\\Controllers\\DepartemenController@index',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::rA7t5Kvp6qZoloN0',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::kHfdOSSmOO1mazjK' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'departemen/store',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'role:administrator,user',
        ),
        'uses' => 'App\\Http\\Controllers\\DepartemenController@store',
        'controller' => 'App\\Http\\Controllers\\DepartemenController@store',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::kHfdOSSmOO1mazjK',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::8O0ogEFqeXmI78rR' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'departemen/edit',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'role:administrator,user',
        ),
        'uses' => 'App\\Http\\Controllers\\DepartemenController@edit',
        'controller' => 'App\\Http\\Controllers\\DepartemenController@edit',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::8O0ogEFqeXmI78rR',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::7ctOyuCE0XxZaWqU' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'departemen/{kode_dept}/update',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'role:administrator,user',
        ),
        'uses' => 'App\\Http\\Controllers\\DepartemenController@update',
        'controller' => 'App\\Http\\Controllers\\DepartemenController@update',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::7ctOyuCE0XxZaWqU',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::yxAObh0QXcvCnE5X' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'departemen/{kode_dept}/delete',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'role:administrator,user',
        ),
        'uses' => 'App\\Http\\Controllers\\DepartemenController@delete',
        'controller' => 'App\\Http\\Controllers\\DepartemenController@delete',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::yxAObh0QXcvCnE5X',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::hhvJm45vvRGyTbfY' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'presensi/approveizinsakit',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'role:administrator,user',
        ),
        'uses' => 'App\\Http\\Controllers\\PresensiController@approveizinsakit',
        'controller' => 'App\\Http\\Controllers\\PresensiController@approveizinsakit',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::hhvJm45vvRGyTbfY',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::DNuajL4LWrCjG8C5' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'presensi/{kode_izin}/batalkanizinsakit',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'role:administrator,user',
        ),
        'uses' => 'App\\Http\\Controllers\\PresensiController@batalkanizinsakit',
        'controller' => 'App\\Http\\Controllers\\PresensiController@batalkanizinsakit',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::DNuajL4LWrCjG8C5',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::6cdFX3UUm8t7GzGi' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'cabang',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'role:administrator,user',
        ),
        'uses' => 'App\\Http\\Controllers\\CabangController@index',
        'controller' => 'App\\Http\\Controllers\\CabangController@index',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::6cdFX3UUm8t7GzGi',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::4dJK4M1KRBExySsh' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'cabang/store',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'role:administrator,user',
        ),
        'uses' => 'App\\Http\\Controllers\\CabangController@store',
        'controller' => 'App\\Http\\Controllers\\CabangController@store',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::4dJK4M1KRBExySsh',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::mQr5dG0BuLvamjzx' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'cabang/edit',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'role:administrator,user',
        ),
        'uses' => 'App\\Http\\Controllers\\CabangController@edit',
        'controller' => 'App\\Http\\Controllers\\CabangController@edit',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::mQr5dG0BuLvamjzx',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::r7aDo0n6cAPEK0Fh' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'cabang/update',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'role:administrator,user',
        ),
        'uses' => 'App\\Http\\Controllers\\CabangController@update',
        'controller' => 'App\\Http\\Controllers\\CabangController@update',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::r7aDo0n6cAPEK0Fh',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::6DaAk8tJTsKIRt0d' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'cabang/{kode_cabang}/delete',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'role:administrator,user',
        ),
        'uses' => 'App\\Http\\Controllers\\CabangController@delete',
        'controller' => 'App\\Http\\Controllers\\CabangController@delete',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::6DaAk8tJTsKIRt0d',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::MIdmE3gC22L7r96H' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'konfigurasi/lokasikantor',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'role:administrator,user',
        ),
        'uses' => 'App\\Http\\Controllers\\KonfigurasiController@lokasikantor',
        'controller' => 'App\\Http\\Controllers\\KonfigurasiController@lokasikantor',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::MIdmE3gC22L7r96H',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::QiIzznSSNJdnLeCZ' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'konfigurasi/updatelokasikantor',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'role:administrator,user',
        ),
        'uses' => 'App\\Http\\Controllers\\KonfigurasiController@updatelokasikantor',
        'controller' => 'App\\Http\\Controllers\\KonfigurasiController@updatelokasikantor',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::QiIzznSSNJdnLeCZ',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::64zuMEsDeemXqdkF' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'konfigurasi/jamkerja',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'role:administrator,user',
        ),
        'uses' => 'App\\Http\\Controllers\\KonfigurasiController@jamkerja',
        'controller' => 'App\\Http\\Controllers\\KonfigurasiController@jamkerja',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::64zuMEsDeemXqdkF',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::wqzRO0ovzfSNkjET' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'konfigurasi/storejamkerja',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'role:administrator,user',
        ),
        'uses' => 'App\\Http\\Controllers\\KonfigurasiController@storejamkerja',
        'controller' => 'App\\Http\\Controllers\\KonfigurasiController@storejamkerja',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::wqzRO0ovzfSNkjET',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::hkif85V0ZwMFKid8' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'konfigurasi/editjamkerja',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'role:administrator,user',
        ),
        'uses' => 'App\\Http\\Controllers\\KonfigurasiController@editjamkerja',
        'controller' => 'App\\Http\\Controllers\\KonfigurasiController@editjamkerja',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::hkif85V0ZwMFKid8',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::0rDSEl3O8HylSAxb' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'konfigurasi/updatejamkerja',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'role:administrator,user',
        ),
        'uses' => 'App\\Http\\Controllers\\KonfigurasiController@updatejamkerja',
        'controller' => 'App\\Http\\Controllers\\KonfigurasiController@updatejamkerja',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::0rDSEl3O8HylSAxb',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::thuLpbcwB2eiprDE' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'konfigurasi/jamkerja/{kode_jam_kerja}/delete',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'role:administrator,user',
        ),
        'uses' => 'App\\Http\\Controllers\\KonfigurasiController@deletejamkerja',
        'controller' => 'App\\Http\\Controllers\\KonfigurasiController@deletejamkerja',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::thuLpbcwB2eiprDE',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::ap6iWXPo1Nn9yMJs' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'konfigurasi/jamkerjadept',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'role:administrator,user',
        ),
        'uses' => 'App\\Http\\Controllers\\KonfigurasiController@jamkerjadept',
        'controller' => 'App\\Http\\Controllers\\KonfigurasiController@jamkerjadept',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::ap6iWXPo1Nn9yMJs',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::FTcWSx0iCeo0KYeo' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'konfigurasi/jamkerjadept/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'role:administrator,user',
        ),
        'uses' => 'App\\Http\\Controllers\\KonfigurasiController@createjamkerjadept',
        'controller' => 'App\\Http\\Controllers\\KonfigurasiController@createjamkerjadept',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::FTcWSx0iCeo0KYeo',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::iYc0k365PsQGmgw4' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'konfigurasi/jamkerjadept/store',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'role:administrator,user',
        ),
        'uses' => 'App\\Http\\Controllers\\KonfigurasiController@storejamkerjadept',
        'controller' => 'App\\Http\\Controllers\\KonfigurasiController@storejamkerjadept',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::iYc0k365PsQGmgw4',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::3C0OkvJ00TbRcAjK' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'konfigurasi/jamkerjadept/{kode_jk_dept}/edit',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'role:administrator,user',
        ),
        'uses' => 'App\\Http\\Controllers\\KonfigurasiController@editjamkerjadept',
        'controller' => 'App\\Http\\Controllers\\KonfigurasiController@editjamkerjadept',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::3C0OkvJ00TbRcAjK',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::ZjkQ9rkSjyOTvFZr' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'konfigurasi/jamkerjadept/{kode_jk_dept}/update',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'role:administrator,user',
        ),
        'uses' => 'App\\Http\\Controllers\\KonfigurasiController@updatejamkerjadept',
        'controller' => 'App\\Http\\Controllers\\KonfigurasiController@updatejamkerjadept',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::ZjkQ9rkSjyOTvFZr',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::c23WknyXaK7Tf4CQ' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'konfigurasi/jamkerjadept/{kode_jk_dept}/show',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'role:administrator,user',
        ),
        'uses' => 'App\\Http\\Controllers\\KonfigurasiController@showjamkerjadept',
        'controller' => 'App\\Http\\Controllers\\KonfigurasiController@showjamkerjadept',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::c23WknyXaK7Tf4CQ',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::bxtQCYKJJZlyPmGv' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'konfigurasi/jamkerjadept/{kode_jk_dept}/delete',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'role:administrator,user',
        ),
        'uses' => 'App\\Http\\Controllers\\KonfigurasiController@deletejamkerjadept',
        'controller' => 'App\\Http\\Controllers\\KonfigurasiController@deletejamkerjadept',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::bxtQCYKJJZlyPmGv',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::kyYmImPJpRHw1aZq' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'konfigurasi/users',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'role:administrator,user',
        ),
        'uses' => 'App\\Http\\Controllers\\UserController@index',
        'controller' => 'App\\Http\\Controllers\\UserController@index',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::kyYmImPJpRHw1aZq',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::sZ3Pg3rghEGZiStP' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'konfigurasi/users/store',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'role:administrator,user',
        ),
        'uses' => 'App\\Http\\Controllers\\UserController@store',
        'controller' => 'App\\Http\\Controllers\\UserController@store',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::sZ3Pg3rghEGZiStP',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::09aCZkNPEeETKcpY' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'konfigurasi/users/edit',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'role:administrator,user',
        ),
        'uses' => 'App\\Http\\Controllers\\UserController@edit',
        'controller' => 'App\\Http\\Controllers\\UserController@edit',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::09aCZkNPEeETKcpY',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::eIoLcvO63YgiEic1' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'konfigurasi/users/{id_user}/update',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'role:administrator,user',
        ),
        'uses' => 'App\\Http\\Controllers\\UserController@update',
        'controller' => 'App\\Http\\Controllers\\UserController@update',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::eIoLcvO63YgiEic1',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::SZK1YUpoNHzUdBDB' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'konfigurasi/users/{id_user}/delete',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'role:administrator,user',
        ),
        'uses' => 'App\\Http\\Controllers\\UserController@delete',
        'controller' => 'App\\Http\\Controllers\\UserController@delete',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::SZK1YUpoNHzUdBDB',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::N4whORY7KMtnTKyH' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'konfigurasi/harilibur',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'role:administrator,user',
        ),
        'uses' => 'App\\Http\\Controllers\\HariliburController@index',
        'controller' => 'App\\Http\\Controllers\\HariliburController@index',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::N4whORY7KMtnTKyH',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::zwceZylmR0Pi0AAI' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'konfigurasi/harilibur/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'role:administrator,user',
        ),
        'uses' => 'App\\Http\\Controllers\\HariliburController@create',
        'controller' => 'App\\Http\\Controllers\\HariliburController@create',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::zwceZylmR0Pi0AAI',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::D5vmnvUB7efGHXs4' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'konfigurasi/harilibur/store',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'role:administrator,user',
        ),
        'uses' => 'App\\Http\\Controllers\\HariliburController@store',
        'controller' => 'App\\Http\\Controllers\\HariliburController@store',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::D5vmnvUB7efGHXs4',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::ifb96GPIQ5ZAlRsw' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'konfigurasi/harilibur/edit',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'role:administrator,user',
        ),
        'uses' => 'App\\Http\\Controllers\\HariliburController@edit',
        'controller' => 'App\\Http\\Controllers\\HariliburController@edit',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::ifb96GPIQ5ZAlRsw',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::7O7qovS5lfFndind' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'konfigurasi/harilibur/{kode_libur}/update',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'role:administrator,user',
        ),
        'uses' => 'App\\Http\\Controllers\\HariliburController@update',
        'controller' => 'App\\Http\\Controllers\\HariliburController@update',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::7O7qovS5lfFndind',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::FyIXb3NX8AsRxJwn' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'konfigurasi/harilibur/{kode_libur}/delete',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'role:administrator,user',
        ),
        'uses' => 'App\\Http\\Controllers\\HariliburController@delete',
        'controller' => 'App\\Http\\Controllers\\HariliburController@delete',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::FyIXb3NX8AsRxJwn',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::XPMziF7T9fMrH6W6' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'konfigurasi/harilibur/{kode_libur}/setkaryawanlibur',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'role:administrator,user',
        ),
        'uses' => 'App\\Http\\Controllers\\HariliburController@setkaryawanlibur',
        'controller' => 'App\\Http\\Controllers\\HariliburController@setkaryawanlibur',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::XPMziF7T9fMrH6W6',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::FLMj9BR42KsmYim0' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'konfigurasi/harilibur/{kode_libur}/setlistkaryawanlibur',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'role:administrator,user',
        ),
        'uses' => 'App\\Http\\Controllers\\HariliburController@setlistkaryawanlibur',
        'controller' => 'App\\Http\\Controllers\\HariliburController@setlistkaryawanlibur',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::FLMj9BR42KsmYim0',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::0DNWj4xOol1YWgJx' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'konfigurasi/harilibur/{kode_libur}/getsetlistkaryawanlibur',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'role:administrator,user',
        ),
        'uses' => 'App\\Http\\Controllers\\HariliburController@getsetlistkaryawanlibur',
        'controller' => 'App\\Http\\Controllers\\HariliburController@getsetlistkaryawanlibur',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::0DNWj4xOol1YWgJx',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::UEBuhtXfTd3PyPmM' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'konfigurasi/harilibur/storekaryawanlibur',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'role:administrator,user',
        ),
        'uses' => 'App\\Http\\Controllers\\HariliburController@storekaryawanlibur',
        'controller' => 'App\\Http\\Controllers\\HariliburController@storekaryawanlibur',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::UEBuhtXfTd3PyPmM',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::O6hvMPDFJN4AS8HP' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'konfigurasi/harilibur/removekaryawanlibur',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'role:administrator,user',
        ),
        'uses' => 'App\\Http\\Controllers\\HariliburController@removekaryawanlibur',
        'controller' => 'App\\Http\\Controllers\\HariliburController@removekaryawanlibur',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::O6hvMPDFJN4AS8HP',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::8fwNyp7POie0sDH4' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'konfigurasi/harilibur/{kode_libur}/getkaryawanlibur',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'role:administrator,user',
        ),
        'uses' => 'App\\Http\\Controllers\\HariliburController@getkaryawanlibur',
        'controller' => 'App\\Http\\Controllers\\HariliburController@getkaryawanlibur',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::8fwNyp7POie0sDH4',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::RyXfgAOZYp1MBAEo' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'cuti',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'role:administrator,user',
        ),
        'uses' => 'App\\Http\\Controllers\\CutiController@index',
        'controller' => 'App\\Http\\Controllers\\CutiController@index',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::RyXfgAOZYp1MBAEo',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::wQzOh0ZtkDizVU4c' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'cuti/store',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'role:administrator,user',
        ),
        'uses' => 'App\\Http\\Controllers\\CutiController@store',
        'controller' => 'App\\Http\\Controllers\\CutiController@store',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::wQzOh0ZtkDizVU4c',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::oD7KQPWrbkgWzic3' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'cuti/edit',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'role:administrator,user',
        ),
        'uses' => 'App\\Http\\Controllers\\CutiController@edit',
        'controller' => 'App\\Http\\Controllers\\CutiController@edit',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::oD7KQPWrbkgWzic3',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::ngHEoYRFBlGkeKNV' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'cuti/{kode_cuti}/update',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'role:administrator,user',
        ),
        'uses' => 'App\\Http\\Controllers\\CutiController@update',
        'controller' => 'App\\Http\\Controllers\\CutiController@update',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::ngHEoYRFBlGkeKNV',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::clodYZkdAX4aqk29' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'cuti/{kode_cuti}/delete',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'role:administrator,user',
        ),
        'uses' => 'App\\Http\\Controllers\\CutiController@delete',
        'controller' => 'App\\Http\\Controllers\\CutiController@delete',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::clodYZkdAX4aqk29',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::QDOXniNkfYjaiUrG' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'createrolepermission',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'O:47:"Laravel\\SerializableClosure\\SerializableClosure":1:{s:12:"serializable";O:46:"Laravel\\SerializableClosure\\Serializers\\Signed":2:{s:12:"serializable";s:528:"O:46:"Laravel\\SerializableClosure\\Serializers\\Native":5:{s:3:"use";a:0:{}s:8:"function";s:309:"function () {

    try {
        \\Spatie\\Permission\\Models\\Role::create([\'name\' => \'admin departemen\']);
        // Permission::create([\'name\' => \'view-karyawan\']);
        // Permission::create([\'name\' => \'view-departemen\']);
        echo "Sukses";
    } catch (\\Exception $e) {
        echo "Error";
    }
}";s:5:"scope";s:37:"Illuminate\\Routing\\RouteFileRegistrar";s:4:"this";N;s:4:"self";s:32:"0000000032f3cd57000000005af0229f";}";s:4:"hash";s:44:"ZXric4vu1mrm6wv7YQQtvaJ8sHq8pYsCU5ly9teoShw=";}}',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::QDOXniNkfYjaiUrG',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::lIKsW6TkdEMS9dmT' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'give-user-role',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'O:47:"Laravel\\SerializableClosure\\SerializableClosure":1:{s:12:"serializable";O:46:"Laravel\\SerializableClosure\\Serializers\\Signed":2:{s:12:"serializable";s:439:"O:46:"Laravel\\SerializableClosure\\Serializers\\Native":5:{s:3:"use";a:0:{}s:8:"function";s:220:"function () {
    try {
        $user = \\App\\Models\\User::findorfail(1);
        $user->assignRole(\'administrator\');
        echo "Sukses";
    } catch (\\Exception $e) {
        //throw $th;
        echo "Error";
    }
}";s:5:"scope";s:37:"Illuminate\\Routing\\RouteFileRegistrar";s:4:"this";N;s:4:"self";s:32:"0000000032f3cde7000000005af0229f";}";s:4:"hash";s:44:"L6YYWcoHuJTfKfb4emgkoaqmPjbK803IWELBz8VVNFA=";}}',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::lIKsW6TkdEMS9dmT',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::QRB3gD97tyXyEJLU' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'give-role-permission',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'O:47:"Laravel\\SerializableClosure\\SerializableClosure":1:{s:12:"serializable";O:46:"Laravel\\SerializableClosure\\Serializers\\Signed":2:{s:12:"serializable";s:461:"O:46:"Laravel\\SerializableClosure\\Serializers\\Native":5:{s:3:"use";a:0:{}s:8:"function";s:242:"function () {
    try {
        $role = \\Spatie\\Permission\\Models\\Role::findorfail(1);
        $role->givePermissionTo(\'view-departemen\');
        echo "Sukses";
    } catch (\\Exception $e) {
        //throw $th;
        echo "Error";
    }
}";s:5:"scope";s:37:"Illuminate\\Routing\\RouteFileRegistrar";s:4:"this";N;s:4:"self";s:32:"0000000032f3cde5000000005af0229f";}";s:4:"hash";s:44:"SvBq0+jLe+yUTtm+YoJbLm7CHgKcYOT0qkR/IFmajzU=";}}',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::QRB3gD97tyXyEJLU',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
  ),
)
);
