User

nik : 12345
password : 12345


/panel

username : adam@gmail.com
password 12345